<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/global.css">
    <!-- <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/data-table.css"> -->
</head>

<body>
    <!-- dashboard starts here -->
    <main>
        <!-- sidebar start -->
        <aside class="main-aside">
            <div class="sidebar-wrapper">
                <!-- logo -->
                <div class="main-logo">
                    <a href="#">
                        <img src="<?php echo e(url('/')); ?>/assets/image/logo.svg" alt="">
                    </a>
                </div>
                <div class="overlay-close"></div>
                <!-- navigations  -->
                <div class="menu-button">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="main-menus">
                    <div class="menu-logo">
                        <a href="#">
                            <img src="<?php echo e(url('/')); ?>/assets/image/logo.jpg" alt="">
                        </a>
                    </div>
                    <ul>


                        <li <?php if(request()->segment(1) == 'students'): ?> class="active" <?php endif; ?>>
                            <a href="<?php echo e(url('/students')); ?>">
                                <i>
                                    <img src="<?php echo e(url('/')); ?>/assets/image/short-code.svg" class="menu-show" alt="">
                                </i>
                                <span>Student</span>
                            </a>
                        </li>
                        <li <?php if(request()->segment(1) == 'add_class'): ?> class="active" <?php endif; ?>>
                            <a href="<?php echo e(url('/add_class')); ?>">
                                <i>
                                    <img src="<?php echo e(url('/')); ?>/assets/image/expertise-area.svg" class="menu-show" alt="">
                                </i>
                                <span>Class</span>
                            </a>
                        </li>

                        <li>

                            <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                                <i>
                                    <img src="<?php echo e(url('/')); ?>/assets/image/logout.svg" class="menu-show" alt="">

                                </i>
                                <span>Log Out</span>


                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        </aside>

        <?php echo $__env->yieldContent('content'); ?>



    </main>
    <!-- dashboard ends here -->

    <!-- data table js -->
    <script src="<?php echo e(url('/')); ?>/assets/js/jquery-3.5.1.min.js"></script>
    
    
    <script src="<?php echo e(url('/')); ?>/assets/js/data-table.js"></script>
   
 
 
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
    <!-- custom js -->
    <script src="<?php echo e(url('/')); ?>/assets/js/custom.js"></script>

    <script>
        $('select').on('change', function() {
            var id = $(this).val();

            $.ajax({
                url: 'getdata',
                method: "get",
                data: {
                    id: id
                },
                success: function(data) {
                    $('#student-table').html(data);
                }
            });

        });
    </script>
    <script>
        $('.delete-confirm').click(function(event) {
            var form = $(this).closest("form");
            var name = $(this).data("name");
            var id = $(this).data("id");
            event.preventDefault();
            swal({
                    title: `Are you sure you want to delete ${name}?`,

                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        $.ajax({
                            url: "<?php echo e(route('add_class.store')); ?>" + '/' + id,
                            type: "DELETE",
                            data: {
                                id: id,
                                "_token": "<?php echo e(csrf_token()); ?>",
                            },
                            success: function(data) {
                                location.reload();


                            }

                        });
                    }
                });
        });
        $('body').on('click','.student-delete',function(event) {
            var form = $(this).closest("form");
            var name = $(this).data("name");
            var id = $(this).data("id");
            event.preventDefault();
            swal({
                    title: `Are you sure you want to delete ${name}?`,

                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        $.ajax({
                            url: "<?php echo e(route('students.store')); ?>" + '/' + id,
                            type: "DELETE",
                            data: {
                                id: id,
                                "_token": "<?php echo e(csrf_token()); ?>",
                            },
                            success: function(data) {
                                location.reload();


                            }

                        });
                    }
                });
        });
        
    $(document).ready( function () {
    $('#student-table').DataTable({
        scrollX:true,
    });
    
} );
    </script>
    
    
</body>

</html><?php /**PATH C:\wamp64\www\school_management\resources\views/layouts/adminlayout.blade.php ENDPATH**/ ?>