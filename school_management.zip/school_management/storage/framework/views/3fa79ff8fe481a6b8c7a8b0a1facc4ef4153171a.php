<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/nextige/public_html/school_management/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>