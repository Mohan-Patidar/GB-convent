<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<html lang="en">

<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>G.B.Convent School</title>


    <link href="<?php echo e(url('/')); ?>/assets/css/global.css" rel="stylesheet">



    <!-- Theme Styles -->
    <!--<link href="<?php echo e(url('/')); ?>/assets/css/space.css" rel="stylesheet">-->
</head>

<body>
    <?php echo $__env->yieldContent('content'); ?>

     <script src="<?php echo e(url('/')); ?>/assets/js/jquery-3.5.1.min.js"></script>
       <script src="<?php echo e(url('/')); ?>/assets/js/bootstrap.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/js/validate.js"></script>
   
    <?php echo $__env->yieldContent('additionalscripts'); ?><?php /**PATH /home/nextige/public_html/school_management/resources/views/layouts/authlayout.blade.php ENDPATH**/ ?>