<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>

    <link href="<?php echo e(url('/')); ?>/assets/css/global.css" rel="stylesheet">



    <!-- Theme Styles -->
    <link href="<?php echo e(url('/')); ?>/assets/css/space.css" rel="stylesheet">
</head>

<body>
    <?php echo $__env->yieldContent('content'); ?>

    <script src="<?php echo e(url('/')); ?>/assets/js/jquery-3.5.1"></script>
    <script src="<?php echo e(url('/')); ?>/assets/js/validate.js"></script>
   
    <?php echo $__env->yieldContent('additionalscripts'); ?><?php /**PATH C:\wamp64\www\school_management\resources\views/layouts/authLayout.blade.php ENDPATH**/ ?>