<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/global.css">
     <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/data-table.css"> 
</head>

<body>
    <!-- dashboard starts here -->
    <main>
        <!-- sidebar start -->
        <aside class="main-aside">
            <div class="sidebar-wrapper">
                <!-- logo -->
                <div class="main-logo">
                    <a href="#">
                        <img src="<?php echo e(url('/')); ?>/assets/image/letter-head.png" alt="">
                    </a>
                </div>
                <div class="overlay-close"></div>
                <!-- navigations  -->
                <div class="menu-button">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="main-menus">
                    <div class="menu-logo">
                        <a href="#">
                            <img src="<?php echo e(url('/')); ?>/assets/image/letter-head.png" alt="">
                        </a>
                    </div>
                    <ul>


                        <li <?php if(request()->segment(1) == 'students'): ?> class="active" <?php endif; ?>>
                            <a href="<?php echo e(url('/students')); ?>">
                                <i>
                                    <img src="<?php echo e(url('/')); ?>/assets/image/awesome-user-graduate.svg" class="menu-show" alt="">
                                </i>
                                <span>Student</span>
                            </a>
                        </li>
                        <li <?php if(request()->segment(1) == 'add_class'): ?> class="active" <?php endif; ?>>
                            <a href="<?php echo e(url('/add_class')); ?>">
                                <i>
                                    <img src="<?php echo e(url('/')); ?>/assets/image/blackboard.svg" class="menu-show" alt="">
                                </i>
                                <span>Class</span>
                            </a>
                        </li>

                        <li>

                            <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                                <i>
                                    <img src="<?php echo e(url('/')); ?>/assets/image/logout-1.svg" class="menu-show" alt="">

                                </i>
                                <span>Log Out</span>


                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        </aside>

        <?php echo $__env->yieldContent('content'); ?>



    </main>
    <!-- dashboard ends here -->

    <!-- data table js -->
     <script src="<?php echo e(url('/')); ?>/assets/js/jquery-3.5.1.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/js/bootstrap.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/js/dataTables.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/js/buttons.html5.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/js/sweetalert.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/js/validate.js"></script>
   
    <!--<script src="https://cdn.datatables.net/searchpanes/1.2.1/js/dataTables.searchPanes.min.js"></script>-->
<!--<script src="https://cdn.datatables.net/select/1.3.1/js/dataTables.select.min.js"></script>-->
    <!-- custom js -->
    <script src="<?php echo e(url('/')); ?>/assets/js/custom.js"></script>

    <script>
        $('select').on('change', function() {
            var id = $(this).val();
            if(id==0){
                location.reload();
            }else{
            $.ajax({
                url: 'getdata',
                method: "get",
                data: {
                    id: id,
                    
                },
                success: function(data) {
                    $('#student-table').html(data);
                }
            });
}
        });
    </script>
  
    <script>
        $('.delete-confirm').click(function(event) {
            var form = $(this).closest("form");
            var name = $(this).data("name");
            var id = $(this).data("id");
            event.preventDefault();
            swal({
                    title: `Are you sure you want to delete ${name}?`,

                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        $.ajax({
                            url: "<?php echo e(route('add_class.store')); ?>" + '/' + id,
                            type: "DELETE",
                            data: {
                                id: id,
                                "_token": "<?php echo e(csrf_token()); ?>",
                            },
                            success: function(data) {
                                location.reload();


                            }

                        });
                    }
                });
        });
        $('body').on('click','.student-delete',function(event) {
            var form = $(this).closest("form");
            var name = $(this).data("name");
            var id = $(this).data("id");
            event.preventDefault();
            swal({
                    title: `Are you sure you want to delete ${name}?`,

                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        $.ajax({
                            url: "<?php echo e(route('students.store')); ?>" + '/' + id,
                            type: "DELETE",
                            data: {
                                id: id,
                                "_token": "<?php echo e(csrf_token()); ?>",
                            },
                            success: function(data) {
                                location.reload();


                            }

                        });
                    }
                });
        });
   
    </script>
   
    <script>
        $('.import').click(function(){
        $("#file").click();
        });
        $('#file').change(function(){
            $('#submit').click();
        });
    </script>
    <script>
 
        $('#export').click(function(){
           $('.buttons-csv').click();
        });
    </script>
    
    
</body>

</html><?php /**PATH /home/nextige/public_html/school_management/resources/views/layouts/adminlayout.blade.php ENDPATH**/ ?>