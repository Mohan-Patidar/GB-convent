

<?php $__env->startSection('content'); ?>


<?php if(Session::has('message')): ?>
<div class="alert alert-success alert-dismissible fade in" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
            aria-hidden="true">×</span></button>
    <p><?php echo e(Session::get('message')); ?></p>
</div>
<?php endif; ?>
        <section class="main-wrapper">
            <div class="page-color">
                <div class="page-header">
                    <div class="page-title">
                        Add Student <span>class</span>
                    </div>
                    <div class="page-btn">
                        <a href="<?php echo e(url('/add_class')); ?>" class="add-btn">
                            <span>
                                    <img src="<?php echo e(url('/')); ?>/assets/image/Icon-arrow-back.svg" class="btn-arrow-show" alt="">
                                    <img src="<?php echo e(url('/')); ?>/assets/image/Icon-arrow-back-2.svg" class="btn-arrow-hide" alt="">
                                </span>
                            <span>Back</span>
                        </a>
                    </div>
                </div>
                <div class="profile-box">
                    <div class="short-code">
                        <form id="class-form" method="Post" action="<?php echo e(route('add_class.store')); ?>"
                        enctype="multipart/form-data" >
                        <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" placeholder="Student Class" name="class_name" id="class_name">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <label class="error" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                           
                            <div class="btn btn-box">
                                <button type="submit" class="add-btn margin-top-15">Add Class</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('additionalscripts'); ?>
<script>
    $("#class-form").validate();
   
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nextige/public_html/school_management/resources/views/admin/class/create.blade.php ENDPATH**/ ?>