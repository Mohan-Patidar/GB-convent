

<?php $__env->startSection('content'); ?>

<div class="page-inner ad-inr">
    <?php if(Session::has('message')): ?>
    <div class="alert alert-success alert-dismissible fade in" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                aria-hidden="true">×</span></button>
        <p><?php echo e(Session::get('message')); ?></p>
    </div>
    <?php endif; ?>
<section class="main-wrapper">
            <div class="page-color">
                <div class="page-header">
                    <div class="page-title">
                        student <span> </span>
                    </div>
                  
                    <div class="page-btn">
                    <form action="<?php echo e(route('import')); ?>" method="POST" enctype="multipart/form-data">

                <?php echo csrf_field(); ?>

                <input type="file" name="file" class="form-control">

                <br>

                <button class="btn btn-success">Import User Data</button>

                <a class="btn btn-warning" href="<?php echo e(route('export')); ?>">Export User Data</a>

            </form>
                        <a href="<?php echo e(route('students.create')); ?>" class="add-btn">Add Student</a>
                    </div>
                </div>
                <div class="form-group">
                                    <label>Class</label>
                                    
                                    <select name="gbs_id" id="gbs_id">
                                    <option value="" selected>Select Class</option>
                                    <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($test->id); ?>" ><?php echo e($test->class_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                <div class="page-table">
                    <table id="student-table" class="table table-striped table-bordered" style="width:100%;">
                        <thead>
                            <tr>
                                <th>S.No.</th>
                                <th>Student Id</th>
                                <th>Profile</th>
                                <th>Name</th>
                                <th>Scholar No.</th>
                                <th>Class</th>
                                <th>Father's Name</th>
                                <th>Mother's Name</th>
                                <th>D.O.B</th>
                                <th>Address</th>
                                <th>Aadhar Number</th>
                                <th>Samagar Id</th>
                                <th>Mobile No. 1</th>
                                <th>Mobile No. 2</th>
                                <th>Bank Acc/No.</th>
                                <th>Session</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="result">
                        <?php $i = 0; ?>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            
                                <td><?php echo ++$i ?></td>
                                <td><?php echo e($student->student_id); ?></td>
                                <td><img  src="<?php echo e(asset('image/profile_picture/' .$student->profile_picture)); ?>" /></td>
                                <td><?php echo e($student->name); ?></td>
                                <td><?php echo e($student->scholar_no); ?></td>
                                <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($test->id == $student->gbs_id): ?>
                                        <td class="sorting_1"><?php echo e($test->class_name); ?></td>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                             
                                <td><?php echo e($student->father_name); ?></td>
                                <td><?php echo e($student->mother_name); ?></td>
                                <td><?php echo e($student->dob); ?></td>
                                <td><?php echo e($student->address); ?></td>
                                <td><?php echo e($student->aadhar_no); ?></td>
                                <td><?php echo e($student->samarg_id); ?></td>
                                <td><?php echo e($student->mobile_no); ?></td>
                                <td><?php echo e($student->mobile_no2); ?></td>
                                <td><?php echo e($student->account_no); ?></td>
                                <td><?php echo e($student->add_session); ?></td>
                                <td>
                                    <div class="d-flex">
                                        <button class="edit-btn">
                                        <a class=""
                                            href="<?php echo e(route('students.edit',$student->id)); ?>">
                                            <img src="<?php echo e(url('/')); ?>/assets/image/Icon-edit.svg" width="16px" alt=""></a>
                                        </button>
                                 
                                        <button type="submit" class="delete-btn student-delete" data-id="<?php echo e($student->id); ?>" data-name="<?php echo e($student->name); ?>" > 
                                            <img src="<?php echo e(url('/')); ?>/assets/image/Icon-delete.svg" width="16px" alt="">
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('additionalscripts'); ?>>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\school_management\resources\views/admin/student/index.blade.php ENDPATH**/ ?>