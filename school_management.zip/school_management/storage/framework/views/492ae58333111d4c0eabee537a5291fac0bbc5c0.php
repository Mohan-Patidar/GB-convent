

<?php $__env->startSection('content'); ?>
<div class="page-inner ad-inr">
    <?php if(Session::has('message')): ?>
    <div class="alert alert-success alert-dismissible fade in" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                aria-hidden="true">×</span></button>
        <p><?php echo e(Session::get('message')); ?></p>
    </div>
    <?php endif; ?>
<section class="main-wrapper">
            <div class="page-color">
                <div class="page-header">
                    <div class="page-title">
                        student <span> class</span>
                    </div>
                    <div class="page-btn">
                        <a href="<?php echo e(route('add_class.create')); ?>" class="add-btn">Add Student Class</a>
                    </div>
                </div>
                <div class="page-table">
                    <table id="example" class="table table-striped table-bordered" style="width:100%;">
                        <thead>
                            <tr>
                                <th>Class Name</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($test->class_name); ?></td>
                                <td>
                                    <div class="d-flex">
                                        <button class="edit-btn">
                                        <a class=""
                                            href="<?php echo e(route('add_class.edit',$test->id)); ?>">
                                            <img src="<?php echo e(url('/')); ?>/assets/image/Icon-edit.svg" width="16px" alt=""></a>
                                        </button>
                                 
                                        <button type="submit" class="delete-btn delete-confirm" data-id="<?php echo e($test->id); ?>" data-name="<?php echo e($test->class_name); ?>"> 
                                            <img src="<?php echo e(url('/')); ?>/assets/image/Icon-delete.svg" width="16px" alt="">
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('additionalscripts'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\school_management\resources\views/admin/class/index.blade.php ENDPATH**/ ?>