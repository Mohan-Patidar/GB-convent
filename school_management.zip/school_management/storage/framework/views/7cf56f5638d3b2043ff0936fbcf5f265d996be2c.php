<?php echo e($slot); ?>

<?php /**PATH /home/nextige/public_html/school_management/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>